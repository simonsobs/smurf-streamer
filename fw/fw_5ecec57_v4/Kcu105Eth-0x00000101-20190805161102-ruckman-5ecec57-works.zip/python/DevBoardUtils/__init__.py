#!/usr/bin/env python

from DevBoardUtils.AxiFanController import *
